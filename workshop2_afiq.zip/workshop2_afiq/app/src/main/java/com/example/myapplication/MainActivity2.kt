package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        val startbutton = findViewById<Button>(R.id.calbutton)
        val bminumber = findViewById<TextView>(R.id.bminumber)
        val bmistatus = findViewById<TextView>(R.id.bmistatus)
        val massage= "Your BMI group is :"

        startbutton.setOnClickListener{
            val berat = findViewById<EditText>(R.id.kotakberat).text.toString().toFloat()
            val tinggi = findViewById<EditText>(R.id.kotaktinggi).text.toString().toFloat()

            val bmi = berat / tinggi / tinggi * 10000
            bminumber.text="BMI:" + bmi

            if(bmi < 18.5){
                bmistatus.text = massage + "Underweight"
            }
            else if(bmi >= 18.5 && bmi <= 24.9){
                bmistatus.text = massage + "Normal weight"
            }
            else if(bmi >= 25.0 && bmi <= 29.9){
                bmistatus.text = massage + "Pre-obesity"
            }
            else if(bmi >= 30 && bmi <= 34.9){
                bmistatus.text = massage + "Obesity class I"
            }
            else if(bmi >= 35.0 && bmi <= 39.9){
                bmistatus.text = massage + "Obesity class II"
            }
            else if(bmi >= 40.0){
                bmistatus.text = massage + "Obesity class III"
            }
        }

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}